#!/bin/sh -e
#
# install_software.sh
#

set +e

# Install KNXD
${TOOLSDIR}/inst_knxd.sh
cd $TOOLSDIR

# Install MQTT
${TOOLSDIR}/inst_mqtt.sh
cd $TOOLSDIR

# Install SmartHomeHG
${TOOLSDIR}/inst_shng.sh
cd $TOOLSDIR

# Install smartVISU
${TOOLSDIR}/inst_sv.sh
cd $TOOLSDIR

# Start SmartHomeHG
${TOOLSDIR}/start_shng.sh
cd $TOOLSDIR

