#!/bin/bash
#
# shng_postinstall.sh
#

# ===== Setting environment =====
export TOOLSDIR=/usr/local/shng
export SHNGDIR=/usr/local/smarthome

if [ ! -f ${TOOLSDIR}/postinstall ]; then
    unset TOOLSDIR
    unset SHNGDIR
    unset LOGFILE
    exit
fi

# ===== Function for creating log file =====
echo_time() {
#    echo `date +'%b %e %R '` "$@"
    echo `date '+%Y-%m-%d %H:%M:%S'` "$@"
}
export LOGFILE=${TOOLSDIR}/install.log


# ===== Starting post os-install installation =====
echo_time "Starting SmartHomeNG post install" >> ${LOGFILE}
cd $TOOLSDIR

# ===== Installing dialog for install-message showed at login =====
echo_time "Installing dialog package" >> ${LOGFILE}
sudo apt -y install dialog 
echo

# ===== Adding test for postinstall screen for user pi =====
sudo echo >>/home/pi/.bashrc
sudo echo >>/home/pi/.bashrc
sudo echo ${TOOLSDIR}/postinstall_test.sh >>/home/pi/.bashrc

# ===== Setting password for user pi =====
echo_time "Setting password for user pi" >> ${LOGFILE}
echo 'pi:shng' | sudo chpasswd


# ===== Waiting for time-sync before updating apt data =====
echo_time "Waiting for time-sync" >> ${LOGFILE}
# Synchronize time to prevent "repository is not valid yet" error from apt
timedatectl show>t.out
grep NTPSynchronized=no t.out
rc=$?

while [ $rc -eq "0" ]
do
    sleep 10
    timedatectl show>t.out
    grep NTPSynchronized=no t.out
    rc=$?
done
rm t.out
echo_time "Time synced" >> ${LOGFILE}
sleep 10

set -x 
# to fix: dpkg-reconfigure: unable to re-open stdin: No file or directory
export DEBIAN_FRONTEND=noninteractive

# ===== Installing git =====
sudo apt-get -y install git-core
echo

# ===== Installing ansible =====
echo_time "Installing ansible package" >> ${LOGFILE}
sudo apt-get -y install ansible
echo

# ===== Add a group shng_targets with entry for localhost =====
echo | sudo tee -a /etc/ansible/hosts
echo | sudo tee -a /etc/ansible/hosts
echo "[shng_targets]" | sudo tee -a /etc/ansible/hosts
echo "localhost              ansible_connection=local" | sudo tee -a /etc/ansible/hosts

# ===== Create a logfile for ansible =====
export ANSIBLE_LOG_PATH=${TOOLSDIR}/ansible.log 
touch $ANSIBLE_LOG_PATH
sudo chmod 666 $ANSIBLE_LOG_PATH
set +x 


# ===== Installing Ansible Playbooks from github =====
cd $TOOLSDIR
sudo mkdir $TOOLSDIR/setup
sudo chmod 777 $TOOLSDIR/setup
cd $TOOLSDIR/setup
sudo git clone git://github.com/smarthomeng/shng-install.git .
cd $TOOLSDIR

set -x
echo "Starting installation of software components (using Ansible)"
echo_time "Starting installation of software components (using Ansible)" >> ${LOGFILE}
cd ${TOOLSDIR}/setup/playbooks
sudo chmod +x setup_rasppi.sh
${TOOLSDIR}/setup/playbooks/setup_rasppi.sh
echo_time "Finished installation of software components" >> ${LOGFILE}
echo "Finished installation of software components"
set -x

cd $TOOLSDIR
sudo mv postinstall postinstall.off
echo_time "Finished SmartHomeNG post install" >> ${LOGFILE}

unset TOOLSDIR
unset SHNGDIR
unset LOGFILE
