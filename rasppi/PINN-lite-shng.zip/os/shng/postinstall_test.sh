
TOOLSDIR=/usr/local/shng

if [ ! -f ${TOOLSDIR}/postinstall ]; then
    exit
fi

if [ -f /usr/bin/dialog ]; then
    dialog --textbox ${TOOLSDIR}/postinstall.msg 16 60
    clear
else
    cat ${TOOLSDIR}/postinstall.msg
fi
